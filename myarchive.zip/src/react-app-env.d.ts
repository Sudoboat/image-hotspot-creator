/// <reference types="react-scripts" />
declare module 'react/jsx-runtime'
declare module 'react-image-crop'
