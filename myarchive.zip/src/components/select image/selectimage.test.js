// const { render } = require('@testing-library/react')
// import SelectImage from '../select image/selectImage'

// test('Button', () => {
//   expect(true).toBe(true)
//   render(<SelectImage />)
//   console.log('working')
// })
